#!/usr/bin/env python
# 2018 ERC subs joy drill,  pubs to serial node 
# "S + up_down_platform + up_down_carot+ cw_ccw_carot+ F"
# ITU Rover Team
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from  rover_control.msg import *


arm =Arm_msgs()

pub=rospy.Publisher("/rover_serial/drill", String, queue_size=50)

def callbackdrill(data):
    arm=data
 
    joint0_str=floattostring(arm.joint0,500)
    joint1_str=floattostring(arm.joint1,500)
    joint2_str=floattostring(arm.joint2,500)
    
    pub.publish("S"+joint0_str+joint1_str+joint2_str+joint2_str+joint2_str+"F")

def main():
  
    rospy.init_node('rover_drill_sub_serial')
    rospy.Subscriber("/drill_teleop", Arm_msgs, callbackdrill)
    rospy.spin()

def floattostring(joint, scalar):
    if joint<0 :
        value = int(joint*-scalar)
        if value<10:
            string = "000"+str(value)
        elif value< 100 and value > 9:
           string = "00"+str(value)
        else:
            string= "0"+str(value)
    else:
        value= int(joint*scalar)
        if value<10:
            string= "100"+str(value)
        elif value < 100 and value > 9:
            string = "10"+str(value)
        else:
            string = "1"+str(value)
    return string

if __name__ == '__main__':
    main()
    rospy.spin()