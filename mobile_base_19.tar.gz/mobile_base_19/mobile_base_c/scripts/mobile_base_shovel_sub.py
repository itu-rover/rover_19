#!/usr/bin/env python
# 2018 ERC subs joy shovel,  pubs to serial node
# " S + led + 1st servo+ 2nd servo + 3nd servo + 4nd servo + 5nd servo + F"
# ITU Rover Team
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from  rover_control.msg import *

old_joint0 = 0
old_joint1 = 0
joint0=0
joint1=0
old_joint2 = 0
old_joint3 = 0
joint2=0
joint3=0
old_joint4 = 0
old_joint5 = 0
joint4=0
joint5=0
old_joint6 = 0
joint6=0
joint0_str="000"
joint1_str="000"
joint2_str="000"
joint3_str="000"
joint4_str="000"
joint5_str="000"

led=" "
arm =Arm_msgs()

pub=rospy.Publisher("/rover_serial/drill", String, queue_size=50)
pub1=rospy.Publisher("/rover_serial/shovel", String, queue_size=50)

def callbackled(data):
    global led
    global joint0_str, joint1_str, joint2_str, joint3_str, joint4_str, joint5_str
    led=data.data
    print(led)

    pub1.publish("S"+str(led)+joint0_str+joint1_str+joint2_str+joint3_str+joint4_str+joint5_str+"F")


def callbackshovel(data):
    arm=data
    
    global old_joint3 ,  old_joint1 , old_joint2 , old_joint4,  old_joint5,  old_joint6, old_joint0,led
    global joint0 , joint1 , joint2 , joint3, joint4 , joint5,  joint6,count
    global joint0_str, joint1_str, joint2_str, joint3_str, joint4_str, joint5_str
    joint0=incrementalfloat(arm.joint0,10,old_joint0)
    joint0_str=floattostringservo(joint0,1)
    old_joint0=joint0
    
    joint1=incrementalfloat(arm.joint1,10,old_joint1)
    joint1_str=floattostringservo(joint1,1)
    old_joint1=joint1
    
    joint2=incrementalfloat(arm.joint2,10,old_joint2)
    joint2_str=floattostringservo(joint2,1)
    old_joint2=joint2
    
    joint3=incrementalfloat(arm.joint3,10,old_joint3)
    joint3_str=floattostringservo(joint3,1)
    old_joint3=joint3
    
    joint4=incrementalfloat(arm.joint4,10,old_joint4)
    joint4_str=floattostringservo(joint4,1)
    old_joint4=joint4

    joint5=incrementalfloat(arm.joint5,10,old_joint5)
    joint5_str=floattostringservo(joint5,1)
    old_joint5=joint5

    # print(str(led))
    pub1.publish("S"+str(led)+joint0_str+joint1_str+joint2_str+joint3_str+joint4_str+joint5_str+"F")
    


def main():
  
    rospy.init_node('rover_shovel_sub_serial')
    rospy.Subscriber("/shovel_teleop", Arm_msgs, callbackshovel)
    rospy.Subscriber("/rover_serial/led", String, callbackled)
    rospy.spin()

def floattostringservo(joint, scalar):
    if joint<0 :
        value = int(joint*-scalar)
        if value<10:
            string = "00"+str(value)
        elif value< 100 and value > 9:
           string = "0"+str(value)
        else:
            string= str(value)
    else:
        value= int(joint*scalar)
        if value<10:
            string= "00"+str(value)
        elif value < 100 and value > 9:
            string = "0"+str(value)
        else:
            string = str(value)
    return string

def incrementalfloat(joint, scalar,old_value):
    value=10
    if joint<0 :
        value =  old_value-scalar
        if value<0:
           value=10

    elif joint>0:
        value = old_value+scalar
        if value >180:
            value=180 
    else :
        value=old_value
    return value

if __name__ == '__main__':
    main()
    rospy.spin()