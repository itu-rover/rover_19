#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Husky teleop code
# ITU Rover Team
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist

def move():
	twist=Twist()
	pub=rospy.Publisher("/husky_velocity_controller/cmd_vel", Twist, queue_size=50)

	while not rospy.is_shutdown():
		
		string=raw_input()
		if(string=='w'):	
			twist.linear.x=1
			twist.angular.z=0
		elif(string=='a'):
			twist.linear.x=-1
			twist.angular.z=0
		elif(string=='s'):	
			twist.angular.z=1
			twist.linear.x=0
		elif(string=='d'):
			twist.angular.z=-1
			twist.linear.x=0
		elif(string=='q'):
			twist.angular.z=0
			twist.linear.x=0

		pub.publish(twist)



if __name__ == '__main__':
	try:
		rospy.init_node('keyboard_teleop')
		move()
	except rospy.ROSInterruptException:
		rospy.loginfo("Exception thrown")

